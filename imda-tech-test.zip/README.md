# Setup

This project runs on Python 3.9.0 entirely on the Python standard library. Simply install Python 3.9.0 with your preferred python version manager.

Class diagrams and flowcharts can be found in their respective markdown files, written in [mermaid markdown](https://mermaid.live/).

To run a demo of this app, simply run the `main.py` file.
