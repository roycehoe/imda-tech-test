
class InvalidMenuSelectionError(Exception):
    pass


class InvalidCoinValueError(Exception):
    pass